import { LLM } from "./dist/llm.js";
import { loadConfig } from "./dist/config.js";

async function run() {
    const config = loadConfig();
    // Temporarily disable groq to test openrouter
    config.groq.apiKey = "";
    const llm = new LLM(config);
    try {
        console.log("Starting chat with tools...");
        const res = await llm.chat({
            systemPrompt: "You are a helpful assistant.",
            messages: [{ role: "user", content: "What time is it in Paris?" }],
            tools: [{
                type: "function",
                function: {
                    name: "get_time",
                    description: "A tool to get the current time in a city",
                    parameters: {
                        type: "object",
                        properties: { city: { type: "string" } },
                        required: ["city"]
                    }
                }
            }]
        });
        console.log("Response:", JSON.stringify(res, null, 2));
    } catch (e) {
        console.error("Error:", e);
    }
}

run();
