import type { Agent } from "../agent.js";
import { rememberFactDef, handleRememberFact } from "../remember-fact.js";
import { recallMemoryDef, handleRecallMemory } from "../recall-memory.js";
import { execute_shell } from "./shell.js";
import { deepResearchToolDef, webSearchToolDef } from "./research.js";
import { fileOperationsToolDef, handleFileOperation, FileManager } from "./file.js";
import type { Config } from "../config.js";

export function registerMemoryTools(agent: Agent) {
    agent.registerTool(rememberFactDef, async (args) => {
        const userId = (args as any).userId;
        return handleRememberFact((agent as any).memory, args, userId);
    });

    agent.registerTool(recallMemoryDef, async (args) => {
        const userId = (args as any).userId;
        return handleRecallMemory((agent as any).semantic, args, userId);
    });
}

const executeShellDef = {
    type: "function" as const,
    function: {
        name: "execute_shell",
        description: "Execute a shell command on the host system and return the output. Use this for system tasks, checking files, running scripts, or gathering environment info.",
        parameters: {
            type: "object",
            properties: {
                command: {
                    type: "string",
                    description: "The shell command to execute."
                },
                timeoutMs: {
                    type: "number",
                    description: "Optional timeout in milliseconds (default 30000)."
                }
            },
            required: ["command"]
        }
    }
};

export function registerShellTools(agent: Agent) {
    agent.registerTool(executeShellDef, async (args: any) => {
        return execute_shell(args.command, args.timeoutMs);
    });
}

export function registerResearchTools(agent: Agent) {
    const research = agent.getResearch();
    
    agent.registerTool(deepResearchToolDef, async (args: any) => {
        const topic = args.topic as string;
        const depth = args.depth as "quick" | "deep" | "comprehensive" || "deep";
        try {
            return await research.deepResearch(topic, depth);
        } catch (err) {
            return `Research failed: ${err}`;
        }
    });

    agent.registerTool(webSearchToolDef, async (args: any) => {
        const query = args.query as string;
        const numResults = args.numResults as number || 10;
        try {
            return await research.searchAndFormat(query, numResults);
        } catch (err) {
            return `Search failed: ${err}`;
        }
    });
}

export function registerFileTools(agent: Agent, config: Config) {
    const fileManager = new FileManager(config);
    
    agent.registerTool(fileOperationsToolDef, async (args: any) => {
        return handleFileOperation(fileManager, args);
    });
}
