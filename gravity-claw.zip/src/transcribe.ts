import OpenAI from "openai";
import type { Config } from "./config.js";
import fs from "node:fs";
import path from "node:path";

export class Transcriber {
    private client: OpenAI;

    constructor(config: Config) {
        this.client = new OpenAI({
            apiKey: config.groq.apiKey,
            baseURL: "https://api.groq.com/openai/v1",
        });
    }

    /**
     * Transcribe an audio file using Groq's Whisper API.
     * Returns the transcribed text.
     */
    async transcribe(filePath: string): Promise<string> {
        const file = fs.createReadStream(filePath);

        try {
            const response = await this.client.audio.transcriptions.create({
                model: "whisper-large-v3-turbo",
                file,
                language: "en",
                prompt: "Gravity Claw assistant transcription: clear, direct, and helpful speech.", // Guiding prompt to reduce hallucinations
            });

            let text = response.text.trim();
            // Filter out common Whisper hallucinations for silence/short clips
            const hallucinations = ["you", "thank you", "thanks for watching"];
            if (hallucinations.includes(text.toLowerCase().replace(/[.,!]/g, ""))) {
                return "";
            }

            return text;
        } catch (err) {
            const errMsg = err instanceof Error ? err.message : String(err);
            console.error(`❌ Transcription error: ${errMsg}`);
            throw err;
        }
    }
}
