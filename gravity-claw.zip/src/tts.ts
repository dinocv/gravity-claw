import fs from "node:fs";
import path from "node:path";
import os from "node:os";

export class TTS {
    private apiKey: string;
    private voiceId: string = "nPczCjzI2devNBz1zQrb"; // Brian - Deep, Resonant, Narrational (Morgan Freeman style)

    constructor(apiKey: string) {
        this.apiKey = apiKey;
    }

    /**
     * Generates speech from text using ElevenLabs API.
     * Returns the path to the temporary audio file.
     */
    async generateSpeech(text: string): Promise<string> {
        const url = `https://api.elevenlabs.io/v1/text-to-speech/${this.voiceId}`;

        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "xi-api-key": this.apiKey,
            },
            body: JSON.stringify({
                text,
                model_id: "eleven_multilingual_v2",
                voice_settings: {
                    stability: 0.5,
                    similarity_boost: 0.75,
                },
            }),
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error(`❌ ElevenLabs Error [${response.status}]: ${errorText}`);
            throw new Error(`ElevenLabs API error: ${errorText}`);
        }

        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        const tmpFile = path.join(os.tmpdir(), `gc_tts_${Date.now()}.mp3`);
        fs.writeFileSync(tmpFile, buffer);

        return tmpFile;
    }
}
