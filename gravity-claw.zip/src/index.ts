import { loadConfig } from "./config.js";
import { Agent } from "./agent.js";
import { Transcriber } from "./transcribe.js";
import { TTS } from "./tts.js";
import { createBot } from "./bot.js";
import { MCPManager } from "./mcp.js";
import { HeartbeatManager } from "./heartbeat.js";
import { registerMemoryTools, registerShellTools, registerResearchTools, registerFileTools } from "./tools/index.js";

// ── Bootstrap ────────────────────────────────────────────────────
console.log("🦀 Gravity Claw starting...");

const config = loadConfig();

console.log(`📡 Model: ${config.openrouter.model}`);
console.log(`🔒 Allowed users: ${config.telegram.allowedUserIds.length}`);
console.log(`🔄 Max iterations: ${config.agent.maxIterations}`);
console.log(`🎤 Voice: Groq Whisper enabled`);
console.log(`🗣️ TTS: ElevenLabs enabled`);
console.log(`🧠 Thinking level: ${config.agent.thinkingLevel || "medium"}`);

// Initialize core components
const agent = new Agent(config);
const transcriber = new Transcriber(config);
const tts = new TTS(config.elevenlabs.apiKey);

// Initialize MCP (Background) - DISABLED FOR TESTING
// const mcp = new MCPManager(agent);
// mcp.init().then(() => {
//     console.log("✅ MCP Initialization complete.");
// }).catch(err => {
//     console.error("❌ MCP Initialization failed:", err);
// });

// ── Register Tools ───────────────────────────────────────────────

registerMemoryTools(agent);
registerShellTools(agent);
registerResearchTools(agent);
registerFileTools(agent, config);

// Tool: speak
// Allows the agent to send a voice message back to the user
agent.registerTool(
    {
        type: "function",
        function: {
            name: "text_to_speech",
            description: "Converts text to speech and sends a voice message. Use this if the user says 'Speak...', 'Say...', or 'Tell me...', or if they explicitly ask for a voice message or to hear you. When using this tool, make the 'text' argument the actual words you want to speak.",
            parameters: {
                type: "object",
                properties: {
                    text: {
                        type: "string",
                        description: "The text to convert to speech.",
                    },
                },
                required: ["text"],
            },
        },
    },
    async (args) => {
        const text = args.text as string;
        try {
            console.log(`🗣️  Generating speech: "${text.slice(0, 30)}..."`);
            const audioPath = await tts.generateSpeech(text);
            agent.queueAudio(audioPath);
            return "Voice message generated and queued for delivery.";
        } catch (err) {
            const errMsg = err instanceof Error ? err.message : String(err);
            return `Error generating speech: ${errMsg}`;
        }
    }
);

// ── Start Bot ────────────────────────────────────────────────────

const bot = createBot(config, agent, transcriber);

// Initialize Heartbeat (Proactive notifications) - DISABLED FOR NOW
// const primaryUser = config.telegram.allowedUserIds[0].toString();
// const heartbeat = new HeartbeatManager(agent, bot, primaryUser);
// heartbeat.start();

function shutdown(signal: string) {
    console.log(`\n⏹️  ${signal} received. Shutting down...`);
    bot.stop();
    process.exit(0);
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

const WEBHOOK_URL = process.env.WEBHOOK_URL;

if (WEBHOOK_URL) {
    console.log(`🔗 Using webhook mode: ${WEBHOOK_URL}`);
    
    import("http").then(http => {
        const port = parseInt(process.env.PORT || "3000");
        
        bot.api.setWebhook(WEBHOOK_URL).then(() => {
            console.log(`✅ Webhook set to: ${WEBHOOK_URL}`);
        }).catch(err => {
            console.error(`❌ Failed to set webhook:`, err);
        });
        
        const server = http.createServer(async (req, res) => {
            if (req.method === "POST") {
                try {
                    const chunks: Buffer[] = [];
                    for await (const chunk of req) {
                        chunks.push(chunk);
                    }
                    const body = Buffer.concat(chunks).toString();
                    await bot.handleUpdate(JSON.parse(body));
                    res.writeHead(200);
                    res.end("OK");
                } catch (err) {
                    console.error(`❌ Handle error:`, err);
                    res.statusCode = 500;
                    res.end("Error");
                }
            } else {
                res.writeHead(200, { "Content-Type": "text/plain" });
                res.end("Gravity Claw is running!");
            }
        });
        
        server.listen(port, () => {
            console.log(`✅ Server listening on port ${port}`);
        });
    });
} else {
    bot.start({
        onStart: (botInfo) => {
            console.log(`\n✅ Gravity Claw is live!`);
            console.log(`   Bot: @${botInfo.username}`);
            console.log(`   Mode: long-polling (no exposed ports)`);
            console.log(`   Ready for messages.\n`);
        },
    });
}
