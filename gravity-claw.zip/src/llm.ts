import OpenAI from "openai";
import type { Config } from "./config.js";

export type ChatMessage = OpenAI.ChatCompletionMessageParam;
export type ToolCall = OpenAI.ChatCompletionMessageToolCall;
export type ToolDef = OpenAI.ChatCompletionTool;

export interface LLMResponse {
    message: OpenAI.ChatCompletionMessage;
    finishReason: string | null;
}

export interface UsageStats {
    model: string;
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    cost: number;
    latencyMs: number;
}

export type ProviderType = "openrouter" | "ollama" | "anthropic" | "google" | "deepseek" | "groq";

export interface ProviderConfig {
    type: ProviderType;
    apiKey?: string;
    baseURL?: string;
    model: string;
    maxTokens?: number;
    thinking?: boolean;
}

export class LLM {
    private config: Config;
    private currentProviderIndex: number = 0;
    private providers: ProviderConfig[] = [];
    public usage: UsageStats[] = [];

    constructor(config: Config) {
        this.config = config;
        this.initializeProviders();
    }

    private initializeProviders() {
        this.providers = [];

        // Add Groq if under rate limit (check before adding)
        if (this.config.groq.apiKey) {
            this.providers.push({
                type: "groq",
                apiKey: this.config.groq.apiKey,
                baseURL: "https://api.groq.com/openai/v1",
                model: "llama-3.1-8b-instant", // Use smaller model to avoid rate limits
                maxTokens: 2048,
            });
        }

        // Add Ollama if configured (FREE!)
        if (this.config.ollama?.baseURL) {
            this.providers.push({
                type: "ollama",
                baseURL: this.config.ollama.baseURL,
                model: this.config.ollama.model || "llama3.2",
                maxTokens: 4096,
            });
        }

        // Add OpenRouter with different model
        if (this.config.openrouter.apiKey) {
            this.providers.push({
                type: "openrouter",
                apiKey: this.config.openrouter.apiKey,
                baseURL: "https://openrouter.ai/api/v1",
                model: this.config.openrouter.model || "google/gemini-2.0-flash-001",
                maxTokens: 4096,
            });
        }

        // Default to groq if no providers
        if (this.providers.length === 0) {
            console.warn("⚠️ No LLM providers configured! Using fallback.");
            this.providers.push({
                type: "groq",
                apiKey: this.config.groq.apiKey,
                baseURL: "https://api.groq.com/openai/v1",
                model: "llama-3.1-8b-instant",
                maxTokens: 2048,
            });
        }

        // Set initial provider to groq
        this.currentProviderIndex = 0;
        console.log(`📡 Using provider: ${this.getCurrentProvider().type} with model: ${this.getCurrentProvider().model}`);
    }

    setModel(model: string) {
        for (const provider of this.providers) {
            if (this.getProviderModelName(provider).includes(model.split("/").pop() || model)) {
                this.currentProviderIndex = this.providers.indexOf(provider);
                return;
            }
        }
        if (this.providers.length > 0) {
            this.currentProviderIndex = 0;
        }
    }

    getCurrentProvider(): ProviderConfig {
        return this.providers[this.currentProviderIndex] || this.providers[0];
    }

    private getProviderModelName(provider: ProviderConfig): string {
        if (provider.type === "openrouter") {
            return provider.model.split("/").pop() || provider.model;
        }
        return provider.model;
    }

    getModel(): string {
        return this.getCurrentProvider().model;
    }

    async chat(opts: {
        systemPrompt: string;
        messages: ChatMessage[];
        tools?: ToolDef[];
        maxTokens?: number;
    }): Promise<LLMResponse> {
        const startTime = Date.now();
        let lastError: Error | null = null;

        for (let attempt = 0; attempt < this.providers.length; attempt++) {
            const provider = this.getCurrentProvider();

            try {
                const result = await this.executeChat(provider, opts);
                const latencyMs = Date.now() - startTime;

                const stats: UsageStats = {
                    model: provider.model,
                    promptTokens: 0,
                    completionTokens: 0,
                    totalTokens: 0,
                    cost: 0,
                    latencyMs,
                };
                stats.cost = this.estimateCost(provider, stats);
                this.usage.push(stats);

                return result;
            } catch (err) {
                lastError = err instanceof Error ? err : new Error(String(err));
                console.error(`❌ Provider ${provider.type} failed: ${lastError.message}`);

                if (this.providers.length > 1) {
                    this.currentProviderIndex = (this.currentProviderIndex + 1) % this.providers.length;
                    console.log(`🔄 Trying next provider: ${this.getCurrentProvider().type}`);
                }
            }
        }

        throw lastError || new Error("All providers failed");
    }

    private async executeChat(provider: ProviderConfig, opts: {
        systemPrompt: string;
        messages: ChatMessage[];
        tools?: ToolDef[];
        maxTokens?: number;
    }): Promise<LLMResponse> {
        const maxTokens = opts.maxTokens || provider.maxTokens || 4096;

        switch (provider.type) {
            case "ollama":
                return this.chatOllama(provider, opts, maxTokens);
            case "anthropic":
                return this.chatAnthropic(provider, opts, maxTokens);
            case "google":
                return this.chatGoogle(provider, opts, maxTokens);
            case "deepseek":
            case "groq":
            case "openrouter":
            default:
                return this.chatOpenAICompatible(provider, opts, maxTokens);
        }
    }

    private async chatOllama(provider: ProviderConfig, opts: any, maxTokens: number): Promise<LLMResponse> {
        const client = new OpenAI({
            apiKey: "ollama",
            baseURL: provider.baseURL,
        });

        const response = await client.chat.completions.create({
            model: provider.model,
            max_tokens: maxTokens,
            messages: [
                { role: "system", content: opts.systemPrompt },
                ...opts.messages,
            ],
            ...(opts.tools?.length ? { tools: opts.tools, tool_choice: "auto" } : {}),
        });

        const choice = response.choices[0];
        return {
            message: choice.message,
            finishReason: choice.finish_reason,
        };
    }

    private async chatAnthropic(provider: ProviderConfig, opts: any, maxTokens: number): Promise<LLMResponse> {
        const client = new OpenAI({
            apiKey: provider.apiKey,
            baseURL: provider.baseURL,
            defaultHeaders: {
                "anthropic-version": "2023-06-01",
            },
        });

        const response = await client.chat.completions.create({
            model: provider.model,
            max_tokens: maxTokens,
            messages: [
                { role: "system", content: opts.systemPrompt },
                ...opts.messages,
            ],
            ...(opts.tools?.length ? { tools: opts.tools, tool_choice: "auto" } : {}),
        });

        const choice = response.choices[0];
        return {
            message: choice.message,
            finishReason: choice.finish_reason,
        };
    }

    private async chatGoogle(provider: ProviderConfig, opts: any, maxTokens: number): Promise<LLMResponse> {
        const client = new OpenAI({
            apiKey: provider.apiKey,
            baseURL: provider.baseURL,
        });

        const response = await client.chat.completions.create({
            model: provider.model,
            max_tokens: maxTokens,
            messages: [
                { role: "system", content: opts.systemPrompt },
                ...opts.messages,
            ],
            ...(opts.tools?.length ? { tools: opts.tools, tool_choice: "auto" } : {}),
        });

        const choice = response.choices[0];
        return {
            message: choice.message,
            finishReason: choice.finish_reason,
        };
    }

    private async chatOpenAICompatible(provider: ProviderConfig, opts: any, maxTokens: number): Promise<LLMResponse> {
        const client = new OpenAI({
            apiKey: provider.apiKey,
            baseURL: provider.baseURL,
            ...(provider.type === "openrouter" ? {
                defaultHeaders: {
                    "HTTP-Referer": "https://github.com/gravity-claw",
                    "X-Title": "Gravity Claw",
                },
            } : {}),
        });

        const useTools = opts.tools && opts.tools.length > 0;

        const response = await client.chat.completions.create({
            model: provider.model,
            max_tokens: maxTokens,
            messages: [
                { role: "system", content: opts.systemPrompt },
                ...opts.messages,
            ],
            ...(useTools ? { tools: opts.tools, tool_choice: "auto" } : {}),
        });

        const choice = response.choices[0];
        return {
            message: choice.message,
            finishReason: choice.finish_reason,
        };
    }

    private estimateCost(provider: ProviderConfig, stats: UsageStats): number {
        const costs: Record<string, { prompt: number; completion: number }> = {
            "claude-3-5-sonnet-20241022": { prompt: 3, completion: 15 },
            "claude-3-opus-20240229": { prompt: 15, completion: 75 },
            "gpt-4o": { prompt: 2.5, completion: 10 },
            "gpt-4o-mini": { prompt: 0.15, completion: 0.6 },
            "gemini-2.0-flash-001": { prompt: 0, completion: 0 },
            "llama-3.3-70b-versatile": { prompt: 0.59, completion: 0.79 },
            "deepseek-chat": { prompt: 0.14, completion: 0.28 },
        };

        const modelCosts = costs[provider.model] || { prompt: 0, completion: 0 };
        return (stats.promptTokens / 1_000_000 * modelCosts.prompt) +
            (stats.completionTokens / 1_000_000 * modelCosts.completion);
    }

    async embed(text: string): Promise<number[]> {
        const provider = this.getCurrentProvider();

        if (provider.type === "ollama") {
            const response = await fetch(`${provider.baseURL}/api/embeddings`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ model: provider.model, prompt: text }),
            });
            const data = await response.json() as { embedding: number[] };
            return data.embedding;
        }

        const client = new OpenAI({
            apiKey: this.config.openrouter.apiKey,
            baseURL: "https://openrouter.ai/api/v1",
        });

        const response = await client.embeddings.create({
            model: "text-embedding-3-small",
            input: text,
        });
        return response.data[0].embedding;
    }

    getUsageStats(): { totalCost: number; totalCalls: number; avgLatency: number; byModel: Record<string, number> } {
        const totalCost = this.usage.reduce((sum, u) => sum + u.cost, 0);
        const totalCalls = this.usage.length;
        const avgLatency = totalCalls > 0 ? this.usage.reduce((sum, u) => sum + u.latencyMs, 0) / totalCalls : 0;

        const byModel: Record<string, number> = {};
        for (const u of this.usage) {
            byModel[u.model] = (byModel[u.model] || 0) + u.cost;
        }

        return { totalCost, totalCalls, avgLatency, byModel };
    }

    resetUsage() {
        this.usage = [];
    }
}
